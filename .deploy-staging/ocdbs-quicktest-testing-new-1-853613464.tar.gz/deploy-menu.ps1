<#
.SYNOPSIS
    Interactive text menu for deploying the Office Club Discord bot suite.

.DESCRIPTION
    Presents a simple numbered menu so you can choose between preflight,
    normal deploy, quick-test deploy, and quick-test revert without
    remembering every parameter.

.EXAMPLE
    PS> .\deploy-menu.ps1
#>

$ErrorActionPreference = 'Stop'

# ============================================================
# Configuration
# ============================================================

$DeployScript = Join-Path $PSScriptRoot 'deploy.ps1'
$RemoteHost = 'tablet@192.168.1.175'
$RemoteRepo = '/opt/office-club-discord-bot-suite'
$DockerService = 'app'
$WebPanelService = ''
Set-Location -LiteralPath $PSScriptRoot
if (-not (Test-Path -LiteralPath $DeployScript -PathType Leaf)) {
    throw "Deploy script is missing: $DeployScript"
}

# ============================================================
# Menu helpers
# ============================================================

function Show-Menu {
    Clear-Host
    Write-Host ''
    Write-Host ' Office Club Discord Bot Suite — Deploy Menu' -ForegroundColor Cyan
    Write-Host '============================================'
    Write-Host ''
    Write-Host '  1. One-click deploy          (commit, push, update bot + webpanel)'
    Write-Host '  2. Preflight only            (validate, no deploy)'
    Write-Host '  3. Deploy selected paths     (stage, commit, push)'
    Write-Host '  4. Quick-test working tree   (sync without commit/push)'
    Write-Host '  5. Quick-test dry-run        (-WhatIf)'
    Write-Host '  6. Revert a quick-test       (restore a backup)'
    Write-Host '  7. Exit'
    Write-Host ''
}

function Read-Choice {
    $Choice = Read-Host -Prompt 'Select an option (1-7)'
    return $Choice.Trim()
}

function Get-DeployBranch {
    $CurrentBranch = (git branch --show-current).Trim()

    if ($CurrentBranch -eq 'master') {
        return $CurrentBranch
    }

    Write-Host ''
    Write-Host "Current branch is '$CurrentBranch' (not master)." -ForegroundColor Yellow
    $Choice = Read-Host -Prompt 'Deploy from this branch? [y/N]'

    if ($Choice -eq 'y' -or $Choice -eq 'Y') {
        return $CurrentBranch
    }

    return $null
}

function Wait-MenuReturn {
    Write-Host ''
    Read-Host -Prompt 'Press Enter to return to the menu'
}

function Read-CommitMessage {
    $Default = 'Update Office Club Discord bot'
    $Message = Read-Host -Prompt "Commit message [$Default]"
    if ([string]::IsNullOrWhiteSpace($Message)) {
        return $Default
    }
    return $Message.Trim()
}

function Read-IncludePath {
    $UserInput = Read-Host -Prompt 'Repository-relative paths to include (space-separated)'
    return ($UserInput.Trim() -split '\s+' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
}

function Get-ChangedPath {
    $StatusLines = @(git status --porcelain -uall)

    if ($LASTEXITCODE -ne 0) {
        throw 'Unable to read Git status.'
    }

    return @(
        $StatusLines |
            ForEach-Object {
                if ($_.Length -le 3) {
                    return
                }

                $Candidate = $_.Substring(3).Trim()

                if ($Candidate -match ' -> ') {
                    $Candidate = ($Candidate -split ' -> ')[-1]
                }

                $Candidate
            } |
                Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    )
}

function Read-BackupLabel {
    $Default = (Get-Date -Format 'yyyyMMddHHmmss')
    $Label = Read-Host -Prompt "Backup label [$Default]"
    if ([string]::IsNullOrWhiteSpace($Label)) {
        return $Default
    }
    return $Label.Trim()
}

function Get-RecentBackup {
    $Command = "ls -1td '$RemoteRepo'.quicktest-backup.* 2>/dev/null | head -10"

    $Output = & ssh `
        -o BatchMode=yes `
        -o ConnectTimeout=10 `
        $RemoteHost `
        $Command

    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($Output)) {
        return @()
    }

    return $Output -split "`r?`n" |
        Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            ForEach-Object { $_.Trim() }
}

function Invoke-RevertBackup {
    param(
        [Parameter(Mandatory = $true)]
        [string]$BackupPath
    )

    if ($BackupPath -notmatch '^/opt/office-club-discord-bot-suite\.quicktest-backup\.[A-Za-z0-9][A-Za-z0-9_-]{0,63}$') {
        throw 'Invalid backup path; refusing restore.'
    }

    $ComposeServices = "'$DockerService'"
    if (-not [string]::IsNullOrWhiteSpace($WebPanelService)) {
        $ComposeServices += " '$WebPanelService'"
    }

    $RemoteCommand = @"
set -e
cd '$RemoteRepo'
test -d '$BackupPath/.git'
sudo -n docker compose config --quiet
FAILED_PATH='$RemoteRepo.before-restore.'`$(date +%s)
test ! -e "`$FAILED_PATH"
RESTORE_PATH='$RemoteRepo.restore.'`$(date +%s)
test ! -e "`$RESTORE_PATH"
sudo -n cp -a '$BackupPath' "`$RESTORE_PATH"
cd "`$RESTORE_PATH"
sudo -n docker compose -p office-club-discord-bot-suite config --quiet
sudo -n docker compose -p office-club-discord-bot-suite build $ComposeServices
cd '$RemoteRepo'
STOPPED=0
recover_restore() {
    result=`$?
    if [ "`$result" -ne 0 ] && [ "`$STOPPED" -eq 1 ]; then
        echo 'Restore failed; recovering previous checkout and rebuilding its services.'
        cd /
        if [ -d "`$FAILED_PATH" ]; then
            if [ -d '$RemoteRepo' ]; then sudo -n mv '$RemoteRepo' "`$RESTORE_PATH.failed"; fi
            sudo -n mv "`$FAILED_PATH" '$RemoteRepo'
        fi
        cd '$RemoteRepo'
        sudo -n docker compose build $ComposeServices && sudo -n docker compose up -d --no-build --force-recreate $ComposeServices || echo 'Automatic recovery failed; manual intervention required.'
    fi
}
trap recover_restore EXIT
STOPPED=1
sudo -n docker compose stop $ComposeServices
cd /
sudo -n mv '$RemoteRepo' "`$FAILED_PATH"
sudo -n mv "`$RESTORE_PATH" '$RemoteRepo'
cd '$RemoteRepo'
sudo -n docker compose up -d --no-build --force-recreate $ComposeServices
curl --retry 12 --retry-delay 5 --retry-connrefused --max-time 5 --fail --silent 'http://127.0.0.1:3000/health/ready'
STOPPED=0
"@

    $RemoteCommand = $RemoteCommand -replace "`r`n", "`n"

    Write-Host ''
    Write-Host "Reverting to backup: $BackupPath" -ForegroundColor Yellow
    Write-Host ''

    & ssh `
        -o BatchMode=yes `
        -o ConnectTimeout=10 `
        $RemoteHost `
        $RemoteCommand

    if ($LASTEXITCODE -ne 0) {
        throw 'Revert failed.'
    }

    Write-Host ''
    Write-Host 'Revert complete.' -ForegroundColor Green
}

# ============================================================
# Main loop
# ============================================================

while ($true) {
    Show-Menu
    $Choice = Read-Choice

    try {
        switch ($Choice) {
            '1' {
                $Paths = @()
                # One-click deploy: commit, push, update server, restart app + webpanel.
                $Branch = Get-DeployBranch
                if (-not $Branch) {
                    Write-Host ''
                    Write-Host 'Deploy cancelled.' -ForegroundColor Yellow
                    break
                }

                $Message = Read-CommitMessage
                $ChangedPaths = Get-ChangedPath

                if ($ChangedPaths.Count -gt 0) {
                    Write-Host ''
                    Write-Host 'Changed files detected:' -ForegroundColor Cyan
                    $ChangedPaths | ForEach-Object { Write-Host "  $_" }

                    Write-Host ''
                    $IncludeAll = Read-Host -Prompt 'Include all changed files? [Y/n]'
                    if ($IncludeAll -eq '' -or $IncludeAll -eq 'Y' -or $IncludeAll -eq 'y') {
                        $Paths = $ChangedPaths
                    }
                    else {
                        $Paths = Read-IncludePath
                    }

                    if ($Paths.Count -eq 0) {
                        Write-Host ''
                        Write-Host 'No paths selected. Returning to menu.' -ForegroundColor Red
                        break
                    }

                    Write-Host ''
                    Write-Host 'This will commit, push, and deploy the selected files.' -ForegroundColor Yellow
                    Write-Host "  Branch:         $Branch" -ForegroundColor Yellow
                    Write-Host "  Commit message: $Message" -ForegroundColor Yellow
                    Write-Host '  Paths:' -ForegroundColor Yellow
                    $Paths | ForEach-Object { Write-Host "    $_" -ForegroundColor Yellow }

                    $Confirm = Read-Host -Prompt 'Type DEPLOY to confirm'
                    if ($Confirm -ne 'DEPLOY') {
                        Write-Host ''
                        Write-Host 'Deploy cancelled.' -ForegroundColor Yellow
                        break
                    }
                }
                else {
                    Write-Host ''
                    Write-Host 'Working tree is clean. Deploying current HEAD.' -ForegroundColor Cyan
                    Write-Host "  Branch: $Branch" -ForegroundColor Cyan

                    $Confirm = Read-Host -Prompt 'Type DEPLOY to confirm'
                    if ($Confirm -ne 'DEPLOY') {
                        Write-Host ''
                        Write-Host 'Deploy cancelled.' -ForegroundColor Yellow
                        break
                    }
                }

                Write-Host ''
                Write-Host "Running: $DeployScript -Message <...> -Branch $Branch" -ForegroundColor DarkGray
                Write-Host ''
                if ($Paths.Count -gt 0) {
                    & $DeployScript -Message $Message -Path $Paths -Branch $Branch
                }
                else {
                    & $DeployScript -Message $Message -Branch $Branch
                }
            }

            '2' {
                $Branch = Get-DeployBranch
                if (-not $Branch) {
                    Write-Host ''
                    Write-Host 'Preflight cancelled.' -ForegroundColor Yellow
                    break
                }

                Write-Host ''
                Write-Host "Running: $DeployScript -Preflight -Branch $Branch" -ForegroundColor DarkGray
                Write-Host ''
                & $DeployScript -Preflight -Branch $Branch
            }

            '3' {
                $Branch = Get-DeployBranch
                if (-not $Branch) {
                    Write-Host ''
                    Write-Host 'Deploy cancelled.' -ForegroundColor Yellow
                    break
                }

                $Message = Read-CommitMessage
                $Paths = Read-IncludePath

                if ($Paths.Count -eq 0) {
                    Write-Host ''
                    Write-Host 'No paths provided. Returning to menu.' -ForegroundColor Red
                    break
                }

                Write-Host ''
                Write-Host "Running: $DeployScript -Message <...> -Path <...> -Branch $Branch" -ForegroundColor DarkGray
                Write-Host ''
                & $DeployScript -Message $Message -Path $Paths -Branch $Branch
            }

            '4' {
                $Branch = Get-DeployBranch
                if (-not $Branch) {
                    Write-Host ''
                    Write-Host 'Quick-test cancelled.' -ForegroundColor Yellow
                    break
                }

                $Label = Read-BackupLabel
                Write-Host ''
                Write-Host "Running: $DeployScript -QuickTest -BackupLabel $Label -WebPanelService $WebPanelService -Branch $Branch" -ForegroundColor DarkGray
                Write-Host ''
                & $DeployScript -QuickTest -BackupLabel $Label -WebPanelService $WebPanelService -Branch $Branch
            }

            '5' {
                $Branch = Get-DeployBranch
                if (-not $Branch) {
                    Write-Host ''
                    Write-Host 'Quick-test cancelled.' -ForegroundColor Yellow
                    break
                }

                $Label = Read-BackupLabel
                Write-Host ''
                Write-Host "Running: $DeployScript -QuickTest -WhatIf -BackupLabel $Label -WebPanelService $WebPanelService -Branch $Branch" -ForegroundColor DarkGray
                Write-Host ''
                & $DeployScript -QuickTest -WhatIf -BackupLabel $Label -WebPanelService $WebPanelService -Branch $Branch
            }

            '6' {
                $Backups = Get-RecentBackup

                if ($Backups.Count -eq 0) {
                    Write-Host ''
                    Write-Host 'No quick-test backups found on the server.' -ForegroundColor Yellow
                    break
                }

                Write-Host ''
                Write-Host 'Recent quick-test backups:' -ForegroundColor Cyan
                for ($i = 0; $i -lt $Backups.Count; $i++) {
                    Write-Host "  $($i + 1). $($Backups[$i])"
                }
                Write-Host ''

                $Selection = Read-Host -Prompt 'Select a backup number (or press Enter to cancel)'
                if ([string]::IsNullOrWhiteSpace($Selection)) {
                    break
                }

                $Index = 0
                if (-not [int]::TryParse($Selection, [ref]$Index) -or $Index -lt 1 -or $Index -gt $Backups.Count) {
                    Write-Host ''
                    Write-Host 'Invalid selection.' -ForegroundColor Red
                    break
                }

                $BackupPath = $Backups[$Index - 1]

                Write-Host ''
                Write-Host 'This will replace the current remote repo with:' -ForegroundColor Yellow
                Write-Host "  $BackupPath" -ForegroundColor Yellow
                Write-Host ''

                $Confirm = Read-Host -Prompt 'Type RESTORE to confirm'
                if ($Confirm -ne 'RESTORE') {
                    Write-Host ''
                    Write-Host 'Revert cancelled.' -ForegroundColor Yellow
                    break
                }

                Invoke-RevertBackup -BackupPath $BackupPath
            }

            '7' {
                exit 0
            }

            default {
                Write-Host ''
                Write-Host 'Invalid option.' -ForegroundColor Red
            }
        }
    }
    catch {
        Write-Host ''
        Write-Host "ERROR: $_" -ForegroundColor Red
    }

    Wait-MenuReturn
}
