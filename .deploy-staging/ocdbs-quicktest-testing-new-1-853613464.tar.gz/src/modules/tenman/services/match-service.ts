import type { PrismaClient } from '../../../generated/prisma/client.js';
import { assertAuthorized, type ActorContext } from '../domain/authorization.js';
import { scheduleJob } from '../../../database/schedule-job.js';

/** Queue formation is owned by QueueService; this service owns active-match operations only. */
export class MatchService {
  public constructor(private readonly prisma: PrismaClient) {}

  public async cancel(matchId: string, actor: ActorContext, correlationId: string): Promise<void> {
    await this.prisma.$transaction(async (transaction) => {
      const match = await transaction.match.findUnique({ where: { id: matchId } });
      if (match === null || ['FINISHED', 'CANCELED', 'FAILED'].includes(match.state))
        throw new Error('Match is already terminal');
      assertAuthorized('STOP', actor, match);
      const updated = await transaction.match.updateMany({
        where: { id: matchId, state: match.state, version: match.version },
        data: {
          state: 'CANCELED',
          cleanupStatus: 'PENDING',
          guildSlotActive: true,
          finishedAt: new Date(),
          version: { increment: 1 },
        },
      });
      if (updated.count !== 1) throw new Error('Match changed while cancellation was in progress');
      await transaction.matchStateTransition.create({
        data: { matchId, fromState: match.state, toState: 'CANCELED', source: 'DISCORD_CANCEL' },
      });
      await scheduleJob(transaction, {
        type: 'CLEANUP_MATCH',
        idempotencyKey: `cleanup:${matchId}`,
        matchId,
        payload: { matchId },
      });
      await transaction.auditEvent.create({
        data: {
          matchId,
          guildId: match.guildId,
          actorDiscordUserId: actor.discordUserId,
          correlationId,
          eventType: 'match_canceled',
          result: 'success',
          metadata: {},
        },
      });
    });
  }

  public findGuildMatch(guildId: string) {
    return this.prisma.match.findFirst({
      where: { guildId, guildSlotActive: true },
      include: { players: { orderBy: { joinedAt: 'asc' } }, profile: true },
    });
  }
}
